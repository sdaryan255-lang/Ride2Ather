package com.ride2ather.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private TextView locationLabel;
    private String receivedText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationLabel = findViewById(R.id.locationLabel);
        Button sendButton = findViewById(R.id.sendButton);
        Button clearButton = findViewById(R.id.clearButton);

        handleIntent(getIntent());

        sendButton.setOnClickListener(v -> sendToMaps());
        clearButton.setOnClickListener(v -> {
            receivedText = "";
            locationLabel.setText("No location received yet");
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (text != null) {
                receivedText = text.toString();
                showReceived(receivedText);
            }
        }
    }

    private void showReceived(String text) {
        String coords = extractCoordinates(text);
        if (coords != null) {
            locationLabel.setText("Location received:\n" + coords + "\n\n" + text);
        } else {
            locationLabel.setText("Shared location/link received:\n\n" + text);
        }
    }

    private String extractCoordinates(String text) {
        Pattern p = Pattern.compile("(-?\\d{1,3}\\.\\d+)\\s*[, ]\\s*(-?\\d{1,3}\\.\\d+)");
        Matcher m = p.matcher(text);
        if (m.find()) return m.group(1) + "," + m.group(2);

        Uri uri = Uri.parse(text);
        String q = uri.getQueryParameter("q");
        if (q != null) {
            Matcher qm = p.matcher(q);
            if (qm.find()) return qm.group(1) + "," + qm.group(2);
        }
        return null;
    }

    private void sendToMaps() {
        if (receivedText.isEmpty()) return;
        String coords = extractCoordinates(receivedText);
        String query = coords != null ? coords : receivedText;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query)
        ));
        startActivity(intent);
    }
}
