# Ride2Ather prototype

Prototype goal:
Rapido/Google Maps -> Share -> Ride2Ather -> receive shared location/link.

Current version:
- Appears in Android's Sharesheet for text.
- Reads shared text/URL.
- Tries to extract latitude/longitude.
- Shows the received content.
- "SEND TO ATHER" currently opens Google Maps as a safe placeholder.

Important:
Direct control of an Ather scooter dashboard is NOT implemented. That requires an officially supported Ather interface/API.

Build:
Open this project in an Android IDE such as Code on the Go/AIDE, or push it to GitHub and use the included workflow.
